import Scripts.FreqLex_core
